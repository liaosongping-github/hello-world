# Cursor Rules（可选）



Rules 在编辑特定文件时**自动**提醒 Agent（如 PRD 必须有验收标准、真相库表字段格式）。



当前已启用：



| 规则文件 | 作用 |

|----------|------|

| [pm-obsidian-cli.mdc](./pm-obsidian-cli.mdc) | 工作区内任意文件读写须经 Obsidian CLI（`alwaysApply`） |

| [pm-phase-r-base-writeback.mdc](./pm-phase-r-base-writeback.mdc) | 写《阶段R文档目录》Base 前须列修改清单并经 PM 确认（`alwaysApply`） |

| [pm-phase-r-module-name-align.mdc](./pm-phase-r-module-name-align.mdc) | 阶段 R 每模块反补前须先对齐 `M{nn}-{研发模块名}` 目录（`alwaysApply`） |
| [pm-phase-r-source-doc-readonly.mdc](./pm-phase-r-source-doc-readonly.mdc) | 读单「文档链接」所链飞书源文档正文不得擅自修改；须先列清单经 PM 确认（`alwaysApply`） |



计划（待定）：



- `pm-global.mdc` — 双线隔离、不编造数据、`[待PM确认]`

- `prd-quality.mdc` — `**/03-PRD/**`

- `truth-base-quality.mdc` — `**/07-产品真相库/**`

